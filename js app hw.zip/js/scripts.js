var pokemonList = [
  {
    name: "Mewtwo",
    height: 7,
    types: ["psychic"],
  },
  {
    name: "Charizard",
    height: 15,
    types: ["Fire", "Flying"],
  },
  {
    name: "Haunter",
    height: 4,
    types: ["Ghost", "Poison"],
  },
];
console.log(pokemonList);
for (var i = 0; i < pokemonList.length; i++) {
  var size;
  if (pokemonList[i].height >= 10) {
    size = " (Wow that's big!)";
  } else if (pokemonList[i].height > 5 && pokemonList[i].height < 10) {
    size = " mediummonster";
  } else {
    size = " smallmonster ";
  }
  var color;
  for (var k = 0; pokemonList[i].types.length; k++) {
    // if (pokemonList[i].types[item] == "psychic") {
    //   color = '<span style="color:purple;"> ';
    // } else if (pokemonList[i].types[item] == "Fire") {
    //   color = '<span style="color:red;"> ';
    // }
  }
  console.log(pokemonList[i].types.length);
  document.write(
    '<div class="box">' +
      pokemonList[i].name +
      " (height: " +
      pokemonList[i].height +
      ")" +
      "<br>" +
      size +
      "<br>" +
      //   pokemonList[i].types +
      "</div>"
  );
}
